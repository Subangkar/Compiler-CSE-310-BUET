//
// Created by SubangkarKr on 09-Apr-18.
//

#ifndef SYMBOLTABLE_CONSTANTS_H
#define SYMBOLTABLE_CONSTANTS_H


#define HASH_TABLE_MAXSIZE 17


#endif //SYMBOLTABLE_CONSTANTS_H
