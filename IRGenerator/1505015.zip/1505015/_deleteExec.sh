gio trash log.txt
# gio trash errors.txt
# gio trash parser.txt
gio trash y.tab.h
gio trash y.tab.c
gio trash y.o
gio trash y.output
gio trash parser.out
gio trash l.o
gio trash lex.yy.c




gio trash code.asm
gio trash optimized-code.asm
